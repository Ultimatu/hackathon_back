
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_candidat` bigint unsigned NOT NULL,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `activities_nom_unique` (`nom`),
  KEY `activities_id_candidat_foreign` (`id_candidat`),
  CONSTRAINT `activities_id_candidat_foreign` FOREIGN KEY (`id_candidat`) REFERENCES `candidats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_id_user_foreign` (`id_user`),
  CONSTRAINT `admin_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `candidats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `candidats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `pt_id` bigint unsigned NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `candidats_user_id_foreign` (`user_id`),
  KEY `candidats_pt_id_foreign` (`pt_id`),
  CONSTRAINT `candidats_pt_id_foreign` FOREIGN KEY (`pt_id`) REFERENCES `parti_politiques` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `candidats_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `candidats` WRITE;
/*!40000 ALTER TABLE `candidats` DISABLE KEYS */;
INSERT INTO `candidats` VALUES (1,3,3,NULL,'2023-08-19 14:29:57','2023-08-19 14:29:57'),(2,4,2,NULL,'2023-08-19 14:31:45','2023-08-19 14:31:45'),(3,5,1,NULL,'2023-08-19 14:32:10','2023-08-19 14:32:10');
/*!40000 ALTER TABLE `candidats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commentaire_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commentaire_responses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_commentaire` bigint unsigned NOT NULL,
  `id_user` bigint unsigned NOT NULL,
  `reponse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commentaire_responses_id_commentaire_foreign` (`id_commentaire`),
  KEY `commentaire_responses_id_user_foreign` (`id_user`),
  CONSTRAINT `commentaire_responses_id_commentaire_foreign` FOREIGN KEY (`id_commentaire`) REFERENCES `commentaires` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `commentaire_responses_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commentaire_responses` WRITE;
/*!40000 ALTER TABLE `commentaire_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `commentaire_responses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `commentaires`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commentaires` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned NOT NULL,
  `id_post` bigint unsigned NOT NULL,
  `commentaire` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commentaires_id_user_foreign` (`id_user`),
  KEY `commentaires_id_post_foreign` (`id_post`),
  CONSTRAINT `commentaires_id_post_foreign` FOREIGN KEY (`id_post`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `commentaires_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `commentaires` WRITE;
/*!40000 ALTER TABLE `commentaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `commentaires` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contactus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sujet` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contactus` WRITE;
/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `elections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `elections` WRITE;
/*!40000 ALTER TABLE `elections` DISABLE KEYS */;
/*!40000 ALTER TABLE `elections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned NOT NULL,
  `id_post` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `likes_id_user_foreign` (`id_user`),
  KEY `likes_id_post_foreign` (`id_post`),
  CONSTRAINT `likes_id_post_foreign` FOREIGN KEY (`id_post`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `likes_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `meet_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meet_participants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned NOT NULL,
  `id_meet` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meet_participants_id_user_foreign` (`id_user`),
  KEY `meet_participants_id_meet_foreign` (`id_meet`),
  CONSTRAINT `meet_participants_id_meet_foreign` FOREIGN KEY (`id_meet`) REFERENCES `meets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `meet_participants_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `meet_participants` WRITE;
/*!40000 ALTER TABLE `meet_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `meet_participants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `meets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_candidat` bigint unsigned NOT NULL,
  `titre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_media` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meets_id_candidat_foreign` (`id_candidat`),
  CONSTRAINT `meets_id_candidat_foreign` FOREIGN KEY (`id_candidat`) REFERENCES `candidats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `meets` WRITE;
/*!40000 ALTER TABLE `meets` DISABLE KEYS */;
/*!40000 ALTER TABLE `meets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2012_08_16_111435_role',1),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_reset_tokens_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2023_08_17_151241_parti_politiques',2),(7,'2023_08_17_153323_elections',2),(8,'2023_08_18_145152_add_photo_to_user',2),(9,'2023_08_18_150623_candidats',2),(10,'2023_08_18_150632_posts',2),(11,'2023_08_18_150641_activities',2),(12,'2023_08_18_150656_votes',2),(13,'2023_08_18_150702_sondages',2),(14,'2023_08_18_150728_commentaire',2),(15,'2023_08_18_150734_meet',2),(16,'2023_08_18_150741_meet_participant',2),(17,'2023_08_18_150827_likes',2),(18,'2023_08_18_150934_admin',2),(19,'2023_08_18_153335_participant_elections',2),(20,'2023_08_18_153743_resultats',2),(21,'2023_08_18_163912_resultats_sondages',2),(22,'2023_08_18_194520_posts_commentaire_repliques',2),(23,'2023_08_19_120223_rename_role_table',3),(24,'2023_08_20_192404_newsletter',4),(25,'2023_08_20_192454_contactus',4),(26,'2023_08_21_140140_add_avis_to_resultats_sondages',4),(27,'2023_08_21_141650_create_table_types_sondages',4),(28,'2023_08_21_141854_add_types_sondages_to_sondages',4),(29,'2023_08_21_153615_drop_type_to_sondage',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `newsletter_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `newsletter` WRITE;
/*!40000 ALTER TABLE `newsletter` DISABLE KEYS */;
INSERT INTO `newsletter` VALUES (1,'tondesoulco@gmail.com',1,'2023-08-21 15:00:37','2023-08-21 15:00:37'),(2,'zetrey35@gmail.com',1,'2023-08-21 15:03:40','2023-08-21 15:03:40');
/*!40000 ALTER TABLE `newsletter` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `parti_politiques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parti_politiques` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parti_politiques_nom_unique` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `parti_politiques` WRITE;
/*!40000 ALTER TABLE `parti_politiques` DISABLE KEYS */;
INSERT INTO `parti_politiques` VALUES (1,'Rassemblement des Républicains (RDR)','Le Rassemblement des Républicains est un parti politique ivoirien fondé en 1994.','storage/partisPolitiques/téléchargement.jpeg_1692457480.jpeg','2023-08-19 14:04:40','2023-08-19 14:04:40'),(2,'Parti Démocratique de Côte d\'Ivoire (PDCI)','Le Parti Démocratique de Côte d\'Ivoire est l\'un des partis politiques les plus anciens du pays.','storage/partisPolitiques/téléchargement (1).jpeg_1692457610.jpeg','2023-08-19 14:06:50','2023-08-19 14:06:50'),(3,'RHDP','Le Rassemblement des Houphouëtistes pour la Démocratie et la Paix est un parti politique ivoirien.','storage/partisPolitiques/téléchargement (2).jpeg_1692457689.jpeg','2023-08-19 14:08:09','2023-08-19 14:08:09');
/*!40000 ALTER TABLE `parti_politiques` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `participant_elections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participant_elections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_candidat` bigint unsigned NOT NULL,
  `id_election` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `participant_elections_id_candidat_foreign` (`id_candidat`),
  KEY `participant_elections_id_election_foreign` (`id_election`),
  CONSTRAINT `participant_elections_id_candidat_foreign` FOREIGN KEY (`id_candidat`) REFERENCES `candidats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `participant_elections_id_election_foreign` FOREIGN KEY (`id_election`) REFERENCES `elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `participant_elections` WRITE;
/*!40000 ALTER TABLE `participant_elections` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant_elections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',1,'ApiToken','3cd44e424049eabe7518aea4d3d8f1d8ef66e74f10d241cd194d14924be480fc','[\"*\"]',NULL,NULL,'2023-08-19 09:26:02','2023-08-19 09:26:02'),(3,'App\\Models\\User',3,'ApiToken','1c51371e2ca95e72491266f2ad758589074c9e39ca2458685d5a0668a556503f','[\"*\"]',NULL,NULL,'2023-08-19 12:17:38','2023-08-19 12:17:38'),(4,'App\\Models\\User',4,'ApiToken','d80a16250f8fb81a62708ebe61ae575e5609b26ad8f0f90cf1a9d5676894fdbc','[\"*\"]',NULL,NULL,'2023-08-19 12:18:26','2023-08-19 12:18:26'),(5,'App\\Models\\User',5,'ApiToken','634bea7da6a3cef18e3b87243fa07f5a6daab3bcf8468442ffaef9efac4acf32','[\"*\"]',NULL,NULL,'2023-08-19 12:19:26','2023-08-19 12:19:26'),(7,'App\\Models\\User',6,'ApiToken','c1ac7a4cd22bbca5865e16f71fd6fa54af6a79a6c814a3da68d6321603a35bca','[\"*\"]',NULL,NULL,'2023-08-19 19:42:57','2023-08-19 19:42:57'),(8,'App\\Models\\User',7,'ApiToken','62497958ad76900af5b0b7978e72f20247393d196baf7efb533fc35e00f5c71c','[\"*\"]',NULL,NULL,'2023-08-19 19:47:50','2023-08-19 19:47:50'),(9,'App\\Models\\User',8,'ApiToken','d51ad44925523434185f050a1b81f47d00877aee18f606fbea194642ad22a928','[\"*\"]',NULL,NULL,'2023-08-19 19:49:56','2023-08-19 19:49:56'),(10,'App\\Models\\User',9,'ApiToken','85d721ec57efe790264e2f6617992eb1b7165165cd99c7891dbcc6204fc0b9ee','[\"*\"]',NULL,NULL,'2023-08-19 20:38:57','2023-08-19 20:38:57'),(11,'App\\Models\\User',10,'ApiToken','91ea9c3a06efa7940bc9fb187ec92d9a5d75f7a0b3f33f71e420acb4f6fc6191','[\"*\"]',NULL,NULL,'2023-08-19 20:40:10','2023-08-19 20:40:10'),(12,'App\\Models\\User',11,'ApiToken','531e345dfb43d28738d13c29178b80f3fbbb04fb3adbe2798266289931878342','[\"*\"]',NULL,NULL,'2023-08-19 20:41:09','2023-08-19 20:41:09'),(13,'App\\Models\\User',12,'ApiToken','edf2c0a49c94db074e79ea3e0fcad35822d428536953f48992fbbe7352fe5b07','[\"*\"]',NULL,NULL,'2023-08-19 20:42:37','2023-08-19 20:42:37'),(14,'App\\Models\\User',13,'ApiToken','9a303dd5fffaba582e1fd0901d2832ca6f7452000389eac9d82acf5d906ed7f5','[\"*\"]',NULL,NULL,'2023-08-19 20:43:30','2023-08-19 20:43:30'),(21,'App\\Models\\User',14,'ApiToken','ef10078490951b3e7908203d32142d264b272cc0dcacb7b3be4486b92629642b','[\"*\"]',NULL,NULL,'2023-08-19 20:54:13','2023-08-19 20:54:13'),(22,'App\\Models\\User',15,'ApiToken','8b90cc9f27aa050faddb7f55790221f3249787da0d60b3720ef8527254b829f3','[\"*\"]',NULL,NULL,'2023-08-19 20:56:16','2023-08-19 20:56:16'),(23,'App\\Models\\User',16,'ApiToken','fc4bec311ffe4c24b1e8ce3512916c8c649a371e6d9cb9745dfadaa2a75adc58','[\"*\"]',NULL,NULL,'2023-08-19 20:57:24','2023-08-19 20:57:24'),(24,'App\\Models\\User',17,'ApiToken','0dbaa919aba0297ddaf371158f1b0c608683ec57156c51098a8e067b0aafef13','[\"*\"]',NULL,NULL,'2023-08-19 20:59:53','2023-08-19 20:59:53'),(25,'App\\Models\\User',18,'ApiToken','4319a41f768b137cbb38455c5affcd4bc06eb1377af5aecf8ceccaa252fb0ea7','[\"*\"]',NULL,NULL,'2023-08-19 21:01:17','2023-08-19 21:01:17'),(32,'App\\Models\\User',22,'ApiToken','5b87ddb5035f63a8aa7900df19795e7983a4187a64b5d206fdafffd1680b2ab7','[\"*\"]',NULL,NULL,'2023-08-19 21:24:52','2023-08-19 21:24:52'),(38,'App\\Models\\User',23,'ApiToken','1d409b81a1161ff8c89486c6bc5bcd9826dcf045211acb67e66b3d3378722046','[\"*\"]',NULL,NULL,'2023-08-19 22:24:19','2023-08-19 22:24:19'),(45,'App\\Models\\User',25,'ApiToken','0166288b02e856f81a9d04f34e98e6d74eb36bf99e3ea3a01a9a08b7849cfdf3','[\"*\"]',NULL,NULL,'2023-08-19 23:14:39','2023-08-19 23:14:39'),(47,'App\\Models\\User',26,'ApiToken','62cc7df7bd1967f8902993767d3c68e24f4b0c26e788d98de68b46c59a0995c8','[\"*\"]',NULL,NULL,'2023-08-20 10:39:26','2023-08-20 10:39:26'),(48,'App\\Models\\User',27,'ApiToken','61a9d61132540c75ccde8be5fefe5e26fbcedd98dcad67576ccc2f84c1252f11','[\"*\"]',NULL,NULL,'2023-08-20 11:45:14','2023-08-20 11:45:14'),(51,'App\\Models\\User',19,'ApiToken','961eb0668b515c8f3e4aaa24ac6f963d2bc8a8a1ea921d10ee18678c6c83751a','[\"*\"]',NULL,NULL,'2023-08-20 16:46:52','2023-08-20 16:46:52'),(56,'App\\Models\\User',20,'ApiToken','d940ba46c7572c85a27941caee0ab8f39a81df417a2cc18a0d77ff6458b64e29','[\"*\"]',NULL,NULL,'2023-08-21 09:02:43','2023-08-21 09:02:43'),(61,'App\\Models\\User',28,'ApiToken','8b8606e5a3db830904623983e8fa4fa5407169087cc41c0ffacc062b6dbe3009','[\"*\"]',NULL,NULL,'2023-08-21 09:39:42','2023-08-21 09:39:42'),(62,'App\\Models\\User',29,'ApiToken','605055a1b15d2b28ee881da3f8e125ba3383687f9694ca1ba33f3e59b75bb844','[\"*\"]',NULL,NULL,'2023-08-21 09:41:44','2023-08-21 09:41:44'),(63,'App\\Models\\User',30,'ApiToken','c5dd1a127b9b4a2021dba9764aee2cd241b014194d4fc5c97ab5ee868fa21762','[\"*\"]',NULL,NULL,'2023-08-21 12:52:26','2023-08-21 12:52:26'),(64,'App\\Models\\User',21,'ApiToken','982df68d31942ae5767eed118b5bbc8a2609fb11b1ce940493238feefb352123','[\"*\"]',NULL,NULL,'2023-08-21 13:47:57','2023-08-21 13:47:57'),(65,'App\\Models\\User',24,'ApiToken','bd8491371dd0a6ea433705faf4bfaafe2845a914bd20d37919a5e7a3ab08e262','[\"*\"]',NULL,NULL,'2023-08-21 13:53:59','2023-08-21 13:53:59'),(66,'App\\Models\\User',2,'ApiToken','9a5fc5535bc0ff4f4b679c73bceb40825be306013660de9a94d62abf5400550d','[\"*\"]','2023-08-21 14:58:21',NULL,'2023-08-21 14:27:27','2023-08-21 14:58:21');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_candidat` bigint unsigned NOT NULL,
  `titre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_media` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_id_candidat_foreign` (`id_candidat`),
  CONSTRAINT `posts_id_candidat_foreign` FOREIGN KEY (`id_candidat`) REFERENCES `candidats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `resultats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_candidat` bigint unsigned NOT NULL,
  `id_election` bigint unsigned NOT NULL,
  `nb_votes` int NOT NULL,
  `rang` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resultats_id_candidat_foreign` (`id_candidat`),
  KEY `resultats_id_election_foreign` (`id_election`),
  CONSTRAINT `resultats_id_candidat_foreign` FOREIGN KEY (`id_candidat`) REFERENCES `candidats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `resultats_id_election_foreign` FOREIGN KEY (`id_election`) REFERENCES `elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `resultats` WRITE;
/*!40000 ALTER TABLE `resultats` DISABLE KEYS */;
/*!40000 ALTER TABLE `resultats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `resultats_sondages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultats_sondages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_sondage` bigint unsigned NOT NULL,
  `choix` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `avis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resultats_sondages_id_sondage_foreign` (`id_sondage`),
  CONSTRAINT `resultats_sondages_id_sondage_foreign` FOREIGN KEY (`id_sondage`) REFERENCES `sondages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `resultats_sondages` WRITE;
/*!40000 ALTER TABLE `resultats_sondages` DISABLE KEYS */;
/*!40000 ALTER TABLE `resultats_sondages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','administrateur du site','2023-08-16 10:55:24',NULL),(2,'Candidat','Candidat aux élections','2023-08-12 17:24:18',NULL),(3,'Electeur','Electeur ou utilisateur lambda du site','2023-08-16 10:55:24',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sondages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sondages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint unsigned NOT NULL,
  `titre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_media` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `commune` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `id_type_sondage` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sondages_id_user_foreign` (`id_user`),
  KEY `sondages_id_type_sondage_foreign` (`id_type_sondage`),
  CONSTRAINT `sondages_id_type_sondage_foreign` FOREIGN KEY (`id_type_sondage`) REFERENCES `types_sondages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sondages_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sondages` WRITE;
/*!40000 ALTER TABLE `sondages` DISABLE KEYS */;
INSERT INTO `sondages` VALUES (1,2,'Sondage Yopougon 1','Vous aimez comment se déroulent les élections à Yopougon?','sondages/default.jpg','active','2023-08-19 00:00:00','2023-08-25 00:00:00','Yopougon','2023-08-19 15:28:39','2023-08-19 15:28:39',NULL),(2,3,'Sondage Yopougon 2','Pensez-vous que les élections à Yopougon sont équitables?','sondages/default.jpg','active','2023-08-20 00:00:00','2023-08-26 00:00:00','Yopougon','2023-08-19 15:30:29','2023-08-19 15:30:29',NULL),(3,3,'Sondage Plateaux 1','Quel est votre opinion sur les élections dans le quartier Plateaux?','sondages/default.jpg','active','2023-08-21 00:00:00','2023-08-27 00:00:00','Plateaux','2023-08-19 15:31:10','2023-08-19 15:31:10',NULL),(4,3,'Sondage Plateaux 2','Avez-vous confiance en l\'intégrité des élections organisées dans le quartier Plateaux?','sondages/default.jpg','active','2023-08-22 00:00:00','2023-08-28 00:00:00','Plateaux','2023-08-19 15:31:49','2023-08-19 15:31:49',NULL),(5,2,'Sondage Cocody 1','Quelles améliorations suggérez-vous pour les élections à Cocody?','sondages/default.jpg','active','2023-08-23 00:00:00','2023-08-29 00:00:00','Cocody','2023-08-19 15:33:31','2023-08-19 15:33:31',NULL),(6,1,'Sondage Cocody 2','Pensez-vous que les élections à Cocody sont transparentes?','sondages/default.jpg','active','2023-08-24 00:00:00','2023-08-30 00:00:00','Cocody','2023-08-19 15:33:46','2023-08-19 15:33:46',NULL),(7,2,'Sondage Marcory 1','Quels sont les défis des élections à Marcory?','sondages/default.jpg','active','2023-08-25 00:00:00','2023-09-01 00:00:00','Marcory','2023-08-19 15:35:12','2023-08-19 15:35:12',NULL),(8,1,'Sondage Adjame 1','Quelle est votre perception des élections à Adjame?','sondages/default.jpg','active','2023-08-27 00:00:00','2023-09-03 00:00:00','Adjame','2023-08-19 15:35:28','2023-08-19 15:35:28',NULL),(9,2,'Sondage Adjame 2','Pensez-vous que les élections à Adjame sont inclusives?','sondages/default.jpg','active','2023-08-28 00:00:00','2023-09-04 00:00:00','Adjame','2023-08-19 15:35:44','2023-08-19 15:35:44',NULL),(10,2,'Sondage sur les ections à Yopougon','Vous aimez comment se déroulent les élections à Yopougon?','sondages/default.jpg','active','2023-08-19 00:00:00','2023-08-25 00:00:00','Yopougon','2023-08-21 14:58:22','2023-08-21 14:58:22',1);
/*!40000 ALTER TABLE `sondages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types_sondages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_sondages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types_sondages` WRITE;
/*!40000 ALTER TABLE `types_sondages` DISABLE KEYS */;
INSERT INTO `types_sondages` VALUES (1,'Education','Les sondages sur l\'éducation','2023-08-21 14:28:15','2023-08-21 14:28:15'),(2,'Election','Les sondages sur les elections','2023-08-21 14:29:29','2023-08-21 14:29:29'),(3,'Questionnaire','Les sondages en questionnaire','2023-08-21 14:30:27','2023-08-21 14:30:27'),(4,'Recensemment','Les sondages en sur les Recensemment','2023-08-21 14:30:51','2023-08-21 14:30:51');
/*!40000 ALTER TABLE `types_sondages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `elector_card` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adresse` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_cni` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commune` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `photo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'koffi','george','12548887',NULL,'1254889','marcory',3,'serge@mail.com','0554051721',NULL,'$2y$10$YM50z8hX4mVi0GW/ybewUOt2plxZtlIxalmJyQ/o6oLID8UoVMnBC',NULL,'2023-08-19 09:26:01','2023-08-19 09:26:01',NULL),(2,'Tonde','Souleymane','E25418255','Yopougon','C552452457','Yopougon',1,'user@example.com','0546472006',NULL,'$2y$10$4N.Hb.dRxcFMPxWCAiMAzOTWsMoM7G88M9CNusd1ucq8WkFwbOC0C',NULL,'2023-08-19 10:47:54','2023-08-19 10:47:54',NULL),(3,'Ndiaye','Ibrahim','E234567','234 Rue Sud','CNI234567','Dakar',2,'candidat4@example.com','2345678901',NULL,'$2y$10$L37ME/K53N6bXM9HsUfJ8uqWvj3dW0VzOySb9uVl11RzhXiUAtrPW',NULL,'2023-08-19 12:17:38','2023-08-19 14:26:10',NULL),(4,'Sow','Malick','E987654','456 Avenue Centrale','CNI987654','Abidjan',2,'candidat2@example.com','9876543210',NULL,'$2y$10$AeAgS7uYi9mx4Qyrk2Mv.ewoUhcakTC3wEcJ/VbPJmbASy264LF2q',NULL,'2023-08-19 12:18:26','2023-08-19 14:31:44',NULL),(5,'Kamara','Fatoumata','E567890','789 Boulevard Nord','CNI567890','Bamako',2,'candidat3@example.com','5678901234',NULL,'$2y$10$UGQtDnz4VDo9ptMSxkRWaOLWW2O5AwWqVkq9kARY7Tp1TZUgY2zae',NULL,'2023-08-19 12:19:25','2023-08-19 14:32:10',NULL),(6,'Souleymane','Tonde',NULL,NULL,'C2545210','Yopougon',3,'tondesoulco@gmail.com','05464720061',NULL,'$2y$10$3K5No.9d7/sJX7yfF2Uj4uj/Myi3tkiyfs9P3TbflaA/IBdReIAmC',NULL,'2023-08-19 19:42:57','2023-08-19 19:42:57',NULL),(7,'Souleymane','Tonde',NULL,NULL,'C679841201346','Adjamé',3,'tondesoulco1@gmail.com','054647200666',NULL,'$2y$10$CsonzXZ18X22BhgRR/tr3OBPB2yvTonIViuSVAdYjxS5hF7BCcpvO',NULL,'2023-08-19 19:47:49','2023-08-19 19:47:49',NULL),(8,'Souleymane','Tonde',NULL,NULL,'C679841201346','Adjamé',3,'tondesoulco2@gmail.com','054647200661',NULL,'$2y$10$hcIUiISxqODAEGcy6E3ykeaZsnRWFz.IxoU1Kf883O.tW1n2XRMrW',NULL,'2023-08-19 19:49:55','2023-08-19 19:49:55',NULL),(9,'azerttyu','dvsfgf',NULL,NULL,NULL,'marcory',3,'serge@email.com','540512458',NULL,'$2y$10$lTfqeSTQeuAqyi0Ewc88WuUxlB24usM5q9yy9c7D5zQMENCSODtZm',NULL,'2023-08-19 20:38:56','2023-08-19 20:38:56',NULL),(10,'ergg','gdhgjh',NULL,NULL,NULL,'marcory',3,'szrge@ggkg','bgchgh',NULL,'$2y$10$OOxhbNbfHHiSzBqtJjFkdeit2DRtsW.r.bAHsrK.328y4eRj0V0R.',NULL,'2023-08-19 20:40:10','2023-08-19 20:40:10',NULL),(11,'defrgef','dcdvev',NULL,NULL,NULL,'marcory',3,'ine@gmail.vom','rfcbihfrh\'f',NULL,'$2y$10$zrLH3RbMAQknuxJK703Sh.RAFwI2h/jlvWu20WWEV43TR8N0yx4ti',NULL,'2023-08-19 20:41:08','2023-08-19 20:41:08',NULL),(12,'defrgenb','dcdvev c',NULL,NULL,NULL,'marcory',3,'ines@gmail.vom','rfcbihfrh\'fhj',NULL,'$2y$10$cVfGqOIGIVlAIXQXkyl6aOpdVZO5l5Fd/YSFalL6mM1J5PXgjLH5W',NULL,'2023-08-19 20:42:37','2023-08-19 20:42:37',NULL),(13,'zzeeerr','szdfrc',NULL,NULL,NULL,'marcory',3,'zetrey@gmail.com','dzcfgefb',NULL,'$2y$10$XobdTMOVqPD.1Kmjiw14puq4.gWzDw4UmFed5/XnMqvbVe/QJtwKq',NULL,'2023-08-19 20:43:29','2023-08-19 20:43:29',NULL),(14,'serge','ine',NULL,NULL,NULL,'marcory',3,'ete@gmail.com','54051248',NULL,'$2y$10$RTz1cBqM5OutjO975TaQCuV.ZBY7AULn5mutXG9Riyt4DF8MleECy',NULL,'2023-08-19 20:54:13','2023-08-19 20:54:13',NULL),(15,'rtzryety','fdgfy',NULL,NULL,NULL,'marcory',3,'d@mail.com','gsfgfvgf',NULL,'$2y$10$oheOEBu7.Y7.X.kcJsAMGeXVnLnnys0PF6cNvjCMUxwMQ5ugftSxO',NULL,'2023-08-19 20:56:15','2023-08-19 20:56:15',NULL),(16,'eqfgfsg','qzrtrhzr yq tgr',NULL,NULL,NULL,'marcory',3,'r@gmail.com','vwcvgf',NULL,'$2y$10$0GHq7SvWKeu09AQBPujrPudVfS/rYiQYYfUppdJcQlwLFHPtCKgKO',NULL,'2023-08-19 20:57:23','2023-08-19 20:57:23',NULL),(17,'ssss','sssxsx',NULL,NULL,NULL,'marcory',3,'azerty@gmail.com','sqxscvf',NULL,'$2y$10$V8G/WMsDrHssbt8UtEkLuuqWpY/5MhyVkEvGmN1krqNvYQ888ye7e',NULL,'2023-08-19 20:59:53','2023-08-19 20:59:53',NULL),(18,'azerty','efzfdfe',NULL,NULL,NULL,'marcory',3,'serge@gmail.ci','fevfvfbgbgr',NULL,'$2y$10$yWMWydyiE4JctnS4rmP9MultoR/.jDQcqmed7mksEOKomSB2sFti.',NULL,'2023-08-19 21:01:17','2023-08-19 21:01:17',NULL),(19,'azerty','zazdy dz',NULL,NULL,NULL,'marcory',3,'ine@email.com','assv uds',NULL,'$2y$10$cugSym3zedUXL3DJTruhV.nRnkqKXq2kHAGC/lBoSxnTSpuOTtGjG',NULL,'2023-08-19 21:09:06','2023-08-19 21:09:06',NULL),(20,'koffi','george','123548887',NULL,'12354889','marcory',3,'sergel@mail.com','05541051721',NULL,'$2y$10$fa7U/tscUFpcm4RY6VunCeYVkaiLAP7nlFRW0O0eFbbHpNT94Uhj2',NULL,'2023-08-19 21:18:02','2023-08-19 21:18:02',NULL),(21,'azertg','fgfhwgdw wdfhgd bg',NULL,NULL,NULL,'marcory',3,'cvfbgb@tm.ci','gfdhhgbfng',NULL,'$2y$10$Z6oBD.n5gl5J1d9YHEvWNefWRLk3IowSgLR.Rkhw7Vi3SGyDWLBm2',NULL,'2023-08-19 21:21:56','2023-08-19 21:21:56',NULL),(22,'azerthh','sddgfhfh',NULL,NULL,NULL,'marcory',3,'cvfbgbez@tm.ci','sg fhgndfh',NULL,'$2y$10$GylL7cyl3MEQDuhYM/dNN.0VzIJnHBhvaMN1aEWb7uAs0YiJfX1yu',NULL,'2023-08-19 21:24:51','2023-08-19 21:24:51',NULL),(23,'hamed','zetrey',NULL,NULL,NULL,'marcory',3,'cvfbgaz@tm.ci','5478665',NULL,'$2y$10$JRK4lb9/DyITAqtCcFL1Xe3dVnyMFUrzPeY2NTB0fVc.SMvNzonSe',NULL,'2023-08-19 22:24:19','2023-08-19 22:24:19',NULL),(24,'yao','yolande',NULL,NULL,NULL,'marcory',3,'yaoyolande070@gmail','0759248570',NULL,'$2y$10$c6zH9qkmhbYc/Scs5TeS1OsmPHeTrzymzhMVXcV1iGKA.OQCPotqa',NULL,'2023-08-19 22:41:08','2023-08-19 22:41:08',NULL),(25,'test','test',NULL,NULL,NULL,'marcory',3,'test@gmail.com','01010101',NULL,'$2y$10$7NOjlkVnVoOzk5fFfs6VwuG10lGOOEz/RXx9cDly2GnEXmHeuJsAG',NULL,'2023-08-19 23:14:39','2023-08-19 23:14:39',NULL),(26,'alexandre','gbamele',NULL,NULL,NULL,'marcory',3,'alex@gmail.com','547851236',NULL,'$2y$10$rvWSzX1/lKDXU4wprB60pOVok6pZfznoGP.M8radDrW19vXO346/e',NULL,'2023-08-20 10:39:26','2023-08-20 10:39:26',NULL),(27,'tanoh','serge',NULL,NULL,NULL,'marcory',3,'sergetanoh13@gmail.com','0705877104',NULL,'$2y$10$ENUoj5cOxwEM7C7.CpvILuDjJfPSMw.nCHooPLvsUNJjhdKza/Riq',NULL,'2023-08-20 11:45:14','2023-08-20 11:45:14',NULL),(28,'ser','defef',NULL,NULL,NULL,'marcory',3,'cvfbgb@t.ci','54051721',NULL,'$2y$10$lWVR7EceqyfcTfSJb7QYIurh8G6I1QJJCaqbdbbJuSuZ0qA5D0DxG',NULL,'2023-08-21 09:39:41','2023-08-21 09:39:41',NULL),(29,'koffi','george','1235q48887',NULL,'123a54889','marcory',3,'sergelq@mail.com','0554a1051721',NULL,'$2y$10$QQ3p3UrGGSZr6LRwP4nYG..YFU8nk9.FZGLccb53XK/VHzCPRqc2q',NULL,'2023-08-21 09:41:44','2023-08-21 09:41:44',NULL),(30,'dqcqdc','dcdqc',NULL,NULL,NULL,'marcory',3,'alex@gmaiql.com','dcqdcd',NULL,'$2y$10$KM1OSGKUjSnE7qhI7Hgcv.AUvohnCk32lmi02X8lU8bMgDizgX5uy',NULL,'2023-08-21 12:52:26','2023-08-21 12:52:26',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `voter_id` bigint unsigned NOT NULL,
  `candidat_id` bigint unsigned NOT NULL,
  `election_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `votes_voter_id_foreign` (`voter_id`),
  KEY `votes_candidat_id_foreign` (`candidat_id`),
  KEY `votes_election_id_foreign` (`election_id`),
  CONSTRAINT `votes_candidat_id_foreign` FOREIGN KEY (`candidat_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `votes_election_id_foreign` FOREIGN KEY (`election_id`) REFERENCES `elections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `votes_voter_id_foreign` FOREIGN KEY (`voter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `votes` WRITE;
/*!40000 ALTER TABLE `votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `votes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

